package com.example.testland_back.daoImpl;

import com.example.testland_back.dao.TestDao;
import com.example.testland_back.entity.UserProblem;
import com.example.testland_back.repository.UserProblemRepository;
import com.example.testland_back.repository.UserTestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TestDaoImpl implements TestDao {
    @Autowired
    private UserProblemRepository userProblemRepository;
    @Autowired
    private UserTestRepository userTestRepository;

    @Override
    public List<UserProblem> findUserProblemsByUserId(Long userId) {
        return userProblemRepository.findUserProblemsByUserId(userId);
    }
}
