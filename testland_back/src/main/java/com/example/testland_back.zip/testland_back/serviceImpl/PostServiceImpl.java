package com.example.testland_back.serviceImpl;

import com.example.testland_back.dao.PostDao;
import com.example.testland_back.dao.UserDao;
import com.example.testland_back.entity.Comment;
import com.example.testland_back.entity.Post;
import com.example.testland_back.entity.User;
import com.example.testland_back.service.PostService;
import com.example.testland_back.util.Msg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class PostServiceImpl implements PostService {
    @Autowired
    private PostDao postDao;
    @Autowired
    private UserDao userDao;

    @Override
    public Msg getPostByUser(String userName){
        List<Post> posts = postDao.getPostByUser(userName);
        if(posts.size() == 0)
            return new Msg(-1, "该用户没有发帖");
        return new Msg(1, " ", posts);
    }

    @Override
    public Msg addPost(Map<String, Object> post){
        User user = userDao.findUserByUsername((String)post.get("userName"));
        if(user == null)
            return new Msg(-1, "该用户不存在");
        Post newPost = postDao.addPost(post);
        if(newPost == null)
            return new Msg(-1, "添加失败");
        return new Msg(1, "添加成功");
    }

    @Override
    public Msg addComment (Map<String, Object> comment){
        Post post = postDao.getPostById(Long.parseLong((String)comment.get("postId")));
        if(post == null)
            return new Msg(-1, "该帖子不存在");
        User user = userDao.findUserByUsername((String)comment.get("username"));
        if(user == null)
            return new Msg(-1, "该用户不存在");
        Comment newComment = postDao.addComment(comment);
        if(newComment == null)
            return new Msg(-1, "添加失败");
        return new Msg(1, "添加成功");
    }
    @Override
    public Msg getPostByPostId(String postId){
        Post post = postDao.getPostById(Long.parseLong(postId));
        if(post == null)
            return new Msg(-1, "该帖子不存在");
        return new Msg(1, " ", post);
    }

    @Override
    public Msg getPosts(){
        List<Post> posts = postDao.getPosts();
        if(posts.size() == 0)
            return new Msg(-1, "没有帖子");
        return new Msg(1, " ", posts);
    }
}
