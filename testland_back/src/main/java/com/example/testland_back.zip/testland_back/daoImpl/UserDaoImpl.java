package com.example.testland_back.daoImpl;

import com.example.testland_back.entity.User;
import com.example.testland_back.entity.UserAuth;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.example.testland_back.repository.UserRepository;
import com.example.testland_back.repository.UserAuthRepository;
import com.example.testland_back.dao.UserDao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class UserDaoImpl implements UserDao{
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserAuthRepository userAuthRepository;

    @Override
    public User findUserByUid(Long uid) {
        return userRepository.findUserByUserId(uid);
    }

    @Override
    public User findUserByUsername(String username) {
        return userRepository.findUserByUsername(username);
    }

    @Override
    public UserAuth getUserAuth(Long uid) {
        return userAuthRepository.findByUserId(uid);
    }

    @Override
    public User addUser(Map<String, String> input){
        User user = new User();
        user.setUsername(input.get("username"));
        user.setAddress(input.get("address"));
        user.setPhone(input.get("phone"));
        user.setEmail(input.get("email"));
        user.setUserStatus(0);
        user.setUserType(1);
        user.setAvatar(input.get("avatar"));
        user.setPassCount(0);
        user.setTryCount(0);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String formattedTime = now.format(formatter);
        user.setActiveTime(formattedTime);
        userRepository.save(user);
        UserAuth userAuth = new UserAuth();
        userAuth.setUserId(user.getUserId());
        userAuth.setPassword(input.get("password"));
        userAuthRepository.save(userAuth);
        return user;
    }
    @Override
    public boolean changeUserStatus(String username) {
        User user = userRepository.findUserByUsername(username);
        if(user == null)
            return false;
        if(user.getUserStatus() == 0)
            user.setUserStatus(1);
        else
            user.setUserStatus(0);
        userRepository.save(user);
        return true;
    }

    @Override
    public List<User> getUserList() {
        List<User> userList = userRepository.findAll();
        List<User> res = new ArrayList<>();
        for(User user : userList){
            if(user.getUserType() == 1)
                res.add(user);
        }
        return res;
    }
}
