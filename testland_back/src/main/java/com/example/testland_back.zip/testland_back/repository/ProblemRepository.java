package com.example.testland_back.repository;

import com.example.testland_back.entity.Problem;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProblemRepository extends JpaRepository<Problem, Long> {
    Problem findProblemByProblemId(Long  problemId);
    List<Problem> findAll();
    Problem findProblemByProblemTitle(String problemTitle);
}
