package com.example.testland_back.daoImpl;

import com.example.testland_back.dao.UserProblemDao;
import com.example.testland_back.entity.UserProblem;
import com.example.testland_back.repository.UserProblemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserProblemDaoImpl implements UserProblemDao {
    @Autowired
    private UserProblemRepository userProblemRepository;
    @Override
    public UserProblem findUserProblemByUserIdAndProblemId(Long userId, Long problemId){
        return userProblemRepository.findByUserIdAndProblemId(userId,problemId);
    }
    @Override
    public UserProblem saveUserProblem(Long userId, Long problemId, Integer testCount, Integer problemStatus){
        UserProblem userProblem = new UserProblem();
        userProblem.setUserId(userId);
        userProblem.setProblemId(problemId);
        userProblem.setTestCount(1);
        userProblem.setProblemStatus(0);
        return userProblemRepository.save(userProblem);
    }
    @Override
    public UserProblem updateUserProblemTestCount(Long userId, Long problemId, Integer testCount){
       userProblemRepository.updateUserProblemTestCount(userId,problemId,testCount);
       return userProblemRepository.findByUserIdAndProblemId(userId,problemId);
    }

}
