package com.example.testland_back.service;

import com.example.testland_back.entity.Problem;
import com.example.testland_back.util.Msg;

import java.util.List;
import java.util.Map;
import java.util.Objects;

public interface ProblemService {
    Msg getAllProblem();
    Msg getProblemById(Long id);
    Msg getProblemByTag(String tag);
    Msg getProblemByCategory(String category);
    Msg addProblem(Map<String, Object> problem);
    String createTestPath(List<Map<String, String>> test, Long problemId);
    Msg addExample(Map<String, Object> example);
    Msg getCategory();
    Problem getProblemByPId(Long id);

    Msg deleteProblem(Long problemId);
}
