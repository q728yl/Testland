package com.example.testland_back.repository;

import com.example.testland_back.entity.UserTest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserTestRepository extends JpaRepository<UserTest, Long> {
    UserTest findAllByUserProblemId(Long userProblemId);
}
