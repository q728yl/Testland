package com.example.testland_back.dao;

import com.example.testland_back.entity.Category;
import com.example.testland_back.entity.Example;
import com.example.testland_back.entity.Problem;

import java.util.List;
import java.util.Map;

public interface ProblemDao {
    List<Problem> getAllProblem();
    Problem getProblemById(Long id);
    List<Problem> getProblemByTag(String tag);
    List<Problem> getProblemByCategory(String category);
    Problem getProblemByProblemTitle(String problemTitle);
    Problem addProblem(Map<String, Object> problem);
    void setTestPath(String tesePath, Long id);
    List<Example> addExample(List<Map<String, String>> examples, Long problemId);
    Category getCategoryById(Long id);

    Problem getProblemByPId(Long id);
    void deleteProblem(Long problemId);
}
