package com.example.testland_back.dao;

public interface UserTestDao {
}
