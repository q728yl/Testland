package com.example.testland_back.controller;

import com.example.testland_back.service.PostService;
import com.example.testland_back.service.TestService;
import com.example.testland_back.util.Msg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
public class PostController {
    @Autowired
    private PostService postService;

    public PostController(PostService postService) {
        this.postService = postService;
    }

    @CrossOrigin
    @PostMapping("/addPost")
    public ResponseEntity<Msg> addProblem(@RequestBody Map<String, Object> post) {
        Msg result = postService.addPost(post);
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }

    @CrossOrigin
    @GetMapping("/getPostByUser")
    public ResponseEntity<Msg> getPostByUser(@RequestParam String userName) {
        Msg result = postService.getPostByUser(userName);
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }

    @CrossOrigin
    @PostMapping("/addComment")
    public ResponseEntity<Msg> addComment(@RequestBody Map<String, Object> comment) {
        Msg result = postService.addComment(comment);
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }
    @CrossOrigin
    @GetMapping("/getPostByPostId")
    public ResponseEntity<Msg> getPostByPostId(@RequestParam String postId) {
        Msg result = postService.getPostByPostId(postId);
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }

    @CrossOrigin
    @PostMapping("/getPosts")
    public ResponseEntity<Msg> getPosts() {
        Msg result = postService.getPosts();
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }



}
