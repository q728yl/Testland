package com.example.testland_back.serviceImpl;

import com.example.testland_back.config.RabbitMQProducer;
import com.example.testland_back.dao.ProblemDao;
import com.example.testland_back.dao.TestDao;
import com.example.testland_back.entity.Problem;
import com.example.testland_back.entity.UserProblem;
import com.example.testland_back.service.ProblemService;
import com.example.testland_back.service.TestService;
import com.example.testland_back.util.Msg;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

@Service
public class TestServiceImpl implements TestService {
    @Autowired
    private TestDao testDao;
    @Autowired
    private ProblemDao problemDao;
    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Override
    public BigDecimal getPassRateOfProblem(Long userId) {
        return null;
    }

    @Override
    public Msg test(Long userId, Long problemId,String language, String code){
        Problem p = problemDao.getProblemByPId(problemId);
        String testcaseAddr =  p.getTestPath();
        System.out.println(testcaseAddr);
        // 构建文件名
        String filename = userId + "-" + problemId + "-" + language;

        // 检查目录中是否有同名文件
        int attempt = 1;
        String extension = "";
        if (language.equals("C++")) {
            extension = ".cpp";
        } else if (language.equals("Python")) {
            extension = ".py";
        } else {
            return new Msg(-1, "不支持的语言类型", null);
        }

        String path = "D:/userCodes/" + filename + extension;
        while (Files.exists(Paths.get(path))) {
            filename = userId + "-" + problemId + "-" + language + "-" + attempt;
            path = "D:/userCodes/" + filename + extension;
            attempt++;
        }

        try {
            Path filePath = Files.createFile(Paths.get(path));
            try (BufferedWriter writer = Files.newBufferedWriter(filePath)) {
                writer.write(code);
            }
            System.out.println("代码保存成功：" + filePath);
            // 构建消息内容
            Map<String, String> message = new HashMap<>();
            message.put("userId", String.valueOf(userId));
            message.put("problemId", String.valueOf(problemId));
            message.put("language", language);
            message.put("codePath", filePath.toString());
            message.put("testcasesPath", testcaseAddr);
            //将代码地址保存在数据库！！


            // 转换消息内容为字节数组
            ObjectMapper objectMapper = new ObjectMapper();
            byte[] payload = objectMapper.writeValueAsBytes(message);
            //生产者发送数据
            rabbitTemplate.convertAndSend(RabbitMQProducer.TEST_EXCHANGE, "boot.haha",payload);
            return new Msg(1, "代码保存成功", filePath);
        } catch (IOException e) {
            e.printStackTrace();
            return new Msg(-1, "代码保存失败", null);
        }

    }


}
