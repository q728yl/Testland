package com.example.testland_back.daoImpl;

import com.example.testland_back.dao.UserTestDao;
import com.example.testland_back.repository.UserTestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserTestDaoImpl implements UserTestDao {
    @Autowired
    private UserTestRepository userTestRepository;

}
