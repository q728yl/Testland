package com.example.testland_back.controller;

import com.example.testland_back.util.Msg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.testland_back.service.UserService;

import java.util.Map;

@RestController
class UserController {
    @Autowired
    private UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @CrossOrigin
    @PostMapping("/login")
    public ResponseEntity<Msg> login(@RequestBody Map<String, String> input) {
        Msg result = userService.check(input.get("user"), input.get("password"));
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }

    @CrossOrigin
    @PostMapping("/register")
    public ResponseEntity<Msg> register(@RequestBody Map<String, String> input) {
        Msg result = userService.register(input);
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }
    @CrossOrigin
    @PostMapping("/changeUserStatus")
    public ResponseEntity<Msg> changeUserStatus(@RequestParam String username) {
        Msg result = userService.changeUserStatus(username);
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }
    @CrossOrigin
    @GetMapping("/getUserList")
    public ResponseEntity<Msg> getUserList() {
        Msg result = userService.getUserList();
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }

    @CrossOrigin
    @GetMapping("/getRankingList")
    public ResponseEntity<Msg> getRankingList() {
        Msg result = userService.getRankingList();
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }
}