package com.example.testland_back.controller;

import com.example.testland_back.entity.UserProblem;
import com.example.testland_back.service.ProblemService;
import com.example.testland_back.service.TestService;
import com.example.testland_back.service.UserProblemService;
import com.example.testland_back.util.Msg;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
public class TestController {
    @Autowired
    private TestService testService;
    @Autowired
    private ProblemService problemService;
    @Autowired
    private UserProblemService userProblemService;
    @Autowired
    private RabbitTemplate rabbitTemplate;

    public TestController(TestService testService) {
        this.testService = testService;
    }

    @CrossOrigin
    @PostMapping("/test")
    public Msg test(@RequestBody Map<String, String> body) {
        Long userId = Long.valueOf(body.get("userId").toString());
        Long problemId = Long.valueOf(body.get("problemId").toString());
        String language = body.get("language").toString();
        String code = body.get("code");

        Msg msg = testService.test(userId, problemId, language, code);
        Msg msg1 = userProblemService.updateUserProblemTestCount(userId,problemId);
        //有了结果以后要更新usertestcases和usertests

        return msg;
    }



}
