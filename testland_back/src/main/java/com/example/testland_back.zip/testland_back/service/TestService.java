package com.example.testland_back.service;

import com.example.testland_back.entity.UserProblem;
import com.example.testland_back.util.Msg;

import java.math.BigDecimal;

public interface TestService {
    BigDecimal getPassRateOfProblem(Long userId);

    Msg test(Long userId, Long problemId, String language, String code);

    ;
}
