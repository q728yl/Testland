package com.example.testland_back.controller;

import com.example.testland_back.service.ProblemService;
import com.example.testland_back.util.Msg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
public class ProblemController {
    @Autowired
    private ProblemService problemService;

    public ProblemController(ProblemService problemService) {
        this.problemService = problemService;
    }

    @CrossOrigin
    @GetMapping("/getAllProblem")
    public ResponseEntity<Msg> getAllProblem() {
        Msg result = problemService.getAllProblem();
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }

    @CrossOrigin
    @GetMapping("/getProblemById")
    public ResponseEntity<Msg> getProblemById(@RequestParam String problemId) {
        Msg result = problemService.getProblemById(Long.parseLong(problemId));
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }

    @CrossOrigin
    @GetMapping("/getProblemByTag")
    public ResponseEntity<Msg> getProblemByTag(@RequestParam String tag) {
        Msg result = problemService.getProblemByTag(tag);
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }

    @CrossOrigin
    @GetMapping("/getProblemByCategory")
    public ResponseEntity<Msg> getProblemByCategory(@RequestParam String category) {
        Msg result = problemService.getProblemByCategory(category);
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }

    @CrossOrigin
    @PostMapping("/addProblem")
    public ResponseEntity<Msg> addProblem(@RequestBody Map<String, Object> problem) {
        Msg result = problemService.addProblem(problem);
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }

    @CrossOrigin
    @PostMapping("/addExample")
    public ResponseEntity<Msg> addExample(@RequestBody Map<String, Object> example) {
        Msg result = problemService.addExample(example);
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }

    @CrossOrigin
    @GetMapping("/getCategory")
    public Msg  getCategory() {
        return problemService.getCategory();

    }
    @CrossOrigin
    @PostMapping("/deleteProblem")
    public ResponseEntity<Msg> deleteProblem(@RequestParam String problemId) {
        Msg result = problemService.deleteProblem(Long.parseLong(problemId));
        if (result.getStatus() >= 0) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }

    }
}
