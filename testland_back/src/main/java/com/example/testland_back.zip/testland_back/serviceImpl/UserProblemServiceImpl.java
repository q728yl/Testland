package com.example.testland_back.serviceImpl;

import com.example.testland_back.dao.UserProblemDao;
import com.example.testland_back.entity.UserProblem;
import com.example.testland_back.service.UserProblemService;
import com.example.testland_back.util.Msg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserProblemServiceImpl implements UserProblemService {
    @Autowired
    private UserProblemDao userProblemDao;

    @Override
    public UserProblem findUserProblemByUserIdAndProblemId(Long userId, Long problemId){
        return userProblemDao.findUserProblemByUserIdAndProblemId( userId,  problemId);
    }
    @Override
    public Msg saveUserProblem(Long userId, Long problemId, Integer testCount, Integer problemStatus){
        UserProblem userProblem = userProblemDao.saveUserProblem(userId,problemId,testCount,problemStatus);
        if(userProblem == null){
            return new Msg(-1, "保存用户题目失败");
        }
        return new Msg(1,"保存用户题目成功",userProblem);

    }
    @Override
    public Msg updateUserProblemTestCount(Long userId, Long problemId){
        UserProblem userProblem = userProblemDao.findUserProblemByUserIdAndProblemId(userId,problemId);
        if(userProblem == null){
            userProblem =userProblemDao.saveUserProblem(userId,problemId,1,0);
            return new Msg(1,"更新用户题目尝试次数成功",userProblem);
        }
        userProblem = userProblemDao.updateUserProblemTestCount(userId,problemId,userProblem.getTestCount()+1);
        if(userProblem == null)
            return new Msg(-1, "更新用户题目尝试次数失败");
        return new Msg(1,"更新用户题目尝试次数成功",userProblem);
    }



}
