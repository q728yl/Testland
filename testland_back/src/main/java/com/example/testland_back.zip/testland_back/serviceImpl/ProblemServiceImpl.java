package com.example.testland_back.serviceImpl;

import com.example.testland_back.dao.ProblemDao;
import com.example.testland_back.entity.Example;
import com.example.testland_back.entity.Tag;
import com.example.testland_back.service.ProblemService;
import com.example.testland_back.util.Msg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.testland_back.entity.Problem;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class ProblemServiceImpl implements ProblemService {
    @Autowired
    private ProblemDao problemDao;

    @Override
    public Msg getAllProblem() {
        List<Problem> problems = problemDao.getAllProblem();
        if(problems.size() == 0)
            return new Msg(-1, "数据库中没有题目");
        List<Map<String, Object>> result = new ArrayList<>();
        for (Problem problem : problems) {
            Map<String, Object> map = new HashMap<>();
            map.put("problemId", problem.getProblemId().toString());
            map.put("problemTitle", problem.getProblemTitle());
            map.put("difficulty", problem.getDifficulty().toString());
            map.put("updateTime", problem.getUpdateTime());
            BigDecimal passRate = BigDecimal.valueOf(problem.getAcCount()).divide(BigDecimal.valueOf(problem.getTestCount()), 2, BigDecimal.ROUND_HALF_UP);
            map.put("passRate", passRate.toString());
            List<Tag> tags = problem.getTags();
            List<String> tagList = new ArrayList<>();
            for (Tag tag : tags) {
                tagList.add(tag.getContent());
            }
            map.put("tags", tagList);
            result.add(map);
        }
        return new Msg(1," ", result);
    }
    @Override
    public Problem getProblemByPId(Long id){
        return problemDao.getProblemByPId(id);
    }

    @Override
    public Msg getProblemById(Long id) {
        Problem problem = problemDao.getProblemById(id);
        if(problem == null)
            return new Msg(-1, "数据库中没有该题目");
        return new Msg(1," ", problem);
    }

    @Override
    public Msg getProblemByTag(String tag) {
        List<Problem> problems = problemDao.getProblemByTag(tag);
        if(problems.size() == 0)
            return new Msg(-1, "数据库中没有该题目");
        return new Msg(1," ", problems);
    }

    @Override
    public Msg getProblemByCategory(String category) {
        List<Problem> problems = problemDao.getProblemByCategory(category);
        if(problems.size() == 0)
            return new Msg(-1, "数据库中没有该题目");
        return new Msg(1," ", problems);
    }

    @Override
    public Msg addProblem(Map<String, Object> problem) {
        Problem problem1 = problemDao.getProblemByProblemTitle((String) problem.get("problemTitle"));
        if(problem1 != null)
            return new Msg(-1, "该题目已存在");

        Problem problem2 = problemDao.addProblem(problem);
        if(problem2 == null)
            return new Msg(-1, "添加题目失败");
        String testPath = createTestPath((List<Map<String, String>>) problem.get("testCases"),  problem2.getProblemId());
        problemDao.setTestPath(testPath,  problem2.getProblemId());
        return new Msg(1, "添加题目成功");
    }

    //    D:\TestLand\data\problem{problemId}\
    @Override
    public String createTestPath(List<Map<String, String>> test, Long problemId) {
        String folderName = "problem" + problemId;
        String folderPath = "D:\\testcases\\" + folderName;

        try {
            File folder = new File(folderPath);
            if (!folder.exists()) {
                folder.mkdirs();
            }

            FileWriter configFileWriter = new FileWriter(folderPath + "\\config.txt");
            Integer testNum = test.size();
            configFileWriter.write(testNum.toString() + "\n");

            for (int i = 0; i < test.size(); i++) {
                Map<String, String> testCase = test.get(i);
                String input = testCase.get("input");
                String output = testCase.get("output");

                String inputFileName = (i + 1) + ".in";
                String outputFileName = (i + 1) + ".ans";

                String inputFilePath = folderPath + "\\" + inputFileName;
                String outputFilePath = folderPath + "\\" + outputFileName;

                FileWriter inputFileWriter = new FileWriter(inputFilePath);
                inputFileWriter.write(input);
                inputFileWriter.close();

                FileWriter outputFileWriter = new FileWriter(outputFilePath);
                outputFileWriter.write(output);
                outputFileWriter.close();

                configFileWriter.write(inputFileName + "," + outputFileName + ",10\n");
            }

            configFileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return folderPath;
    }


    @Override
    public Msg addExample(Map<String, Object> examples) {
        Problem problem = problemDao.getProblemById(Long.parseLong((String) examples.get("problemId")));
        if(problem == null)
            return new Msg(-1, "数据库中没有该题目");
        List<Example> examples1 = problemDao.addExample((List<Map<String, String>>) examples.get("examples"), problem.getProblemId());
        if(examples1 == null)
            return new Msg(-1, "添加样例失败");
        return new Msg(1, "添加样例成功");
    }

    @Override
    public Msg getCategory(){
        List<Problem> problems= problemDao.getAllProblem();
        Map<String, Integer> categoryMap=new HashMap<>();
        //统计每个分类的问题数量
        for (Problem problem:problems) {
            String s = problemDao.getCategoryById(problem.getCategoryId()).getContent();
            if (categoryMap.containsKey(s)) {
                categoryMap.put(s, categoryMap.get(s)+1);
            }else {
                categoryMap.put(s, 1);
            }

        }
        if(categoryMap.isEmpty()){
            return new  Msg(0,"题库为空",null);
        }

        return new Msg(1,"获取问题类别成功",categoryMap);
    }
    @Override
    public Msg deleteProblem(Long problemId) {
        Problem problem = problemDao.getProblemById(problemId);
        if(problem == null)
            return new Msg(-1, "数据库中没有该题目");
        problemDao.deleteProblem(problemId);
        if(problemDao.getProblemById(problemId) != null)
            return new Msg(-1, "删除题目失败");
        return new Msg(1, "删除题目成功");
    }

}
