package com.example.testland_back.daoImpl;

import com.example.testland_back.dao.ProblemDao;
import com.example.testland_back.entity.*;
import com.example.testland_back.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class ProblemDaoImpl implements ProblemDao {
    @Autowired
    private ProblemRepository problemRepository;
    @Autowired
    private TagRepository tagRepository;
    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private ExampleRepository exampleRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserProblemRepository userProblemRepository;

    @Override
    public List<Problem> getAllProblem() {
        return problemRepository.findAll();
    }

    @Override
    public Problem getProblemById(Long id) {
        return problemRepository.findProblemByProblemId(id);
    }
    @Override
    public Problem getProblemByPId(Long id){
        return problemRepository.findProblemByProblemId(id);
    }
    @Override
    public List<Problem> getProblemByTag(String tag) {
        Tag tag1 = tagRepository.findTagByContent(tag);
        return tag1.getProblems();
    }

    @Override
    public List<Problem> getProblemByCategory(String category) {
        Category category1 = categoryRepository.findCategoryByContent(category);
        return category1.getProblems();
    }

    @Override
    public Problem getProblemByProblemTitle(String problemTitle) {
        return problemRepository.findProblemByProblemTitle(problemTitle);
    }

    @Override
    public Problem addProblem(Map<String, Object> problem){
        Problem problem1 = new Problem();
        problem1.setProblemTitle((String) problem.get("problemTitle"));
        problem1.setDescription((String) problem.get("description"));
        String difficultyString = (String) problem.get("difficulty");
        if (difficultyString != null) {
            problem1.setDifficulty(Integer.parseInt(difficultyString));
        }
        problem1.setHint((String) problem.get("hint"));
        problem1.setTestCount(0);
        problem1.setAcCount(0);
        problem1.setWaCount(0);
        problem1.setTleCount(0);
        problem1.setReCount(0);
        problem1.setMleCount(0);
        Category category = categoryRepository.findCategoryByContent((String) problem.get("category"));
        if(category != null)
            problem1.setCategoryId(category.getCategoryId());
        else{
            Category category1 = new Category();
            category1.setContent((String) problem.get("category"));
            categoryRepository.save(category1);
            problem1.setCategoryId(category1.getCategoryId());
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String formattedTime = now.format(formatter);
        problem1.setUpdateTime(formattedTime);

        List<Tag> tags = new ArrayList<>();
        List<String> inputs = (List<String>) problem.get("tags");
        if (inputs != null) {
            for(String tag: inputs){
                Tag tag1 = tagRepository.findTagByContent(tag);
                if(tag1 == null){
                    Tag tag2 = new Tag();
                    tag2.setContent(tag);
                    tagRepository.save(tag2);
//                    tag2.getProblems().add(problem1);
                    if(tag2.getProblems() == null)
                        tag2.setProblems(new ArrayList<>());
                    tag2.getProblems().add(problem1);
                    tags.add(tag2);
                }
                else{
                    tag1.getProblems().add(problem1);
                    tags.add(tag1);
                }
            }
        }
        problem1.setTags(tags);
        problemRepository.save(problem1);

        Problem problem2 = problemRepository.findProblemByProblemTitle(problem1.getProblemTitle());
        List<Map<String, String>> exampleInputs = (List<Map<String, String>>) problem.get("examples");
        problem2.setExamples(addExample(exampleInputs, problem2.getProblemId()));

        return problem2;
    }

    @Override
    public void setTestPath(String tesePath, Long id) {
        Problem  problem = problemRepository.findProblemByProblemId(id);
        if(problem == null)
            return;
        problem.setTestPath(tesePath);
        problemRepository.save(problem);
    }

    @Override
    public List<Example> addExample(List<Map<String, String>> examples, Long problemId){
        List<Example> exampleList = new ArrayList<>();
        for(Map<String, String> example: examples){
            Example example1 = new Example();
            example1.setInput(example.get("input"));
            example1.setOutput(example.get("output"));
            example1.setExplanation(example.get("explanation"));
            example1.setProblemId(problemId);
            exampleRepository.save(example1);
            exampleList.add(example1);
        }
        return exampleList;

    }

    @Override
    public Category getCategoryById(Long id){
        return categoryRepository.findCategoryByCategoryId(id);
    }
    @Override
    public void deleteProblem(Long problemId){
        Problem problem = problemRepository.findProblemByProblemId(problemId);
        if(problem == null)
            return;
        List<Tag> tags = problem.getTags();
        for(Tag tag: tags){
            tag.getProblems().remove(problem);
            tagRepository.save(tag);
        }
        List<Example> examples = problem.getExamples();
        for(Example example: examples){
            exampleRepository.delete(example);
        }
//        Category category = categoryRepository.findCategoryByCategoryId(problem.getCategoryId());
//        category.getProblems().remove(problem);
//        categoryRepository.save(category);
        List<UserProblem> userProblems = userProblemRepository.findUserProblemsByProblemId(problemId);
        for(UserProblem userProblem: userProblems){
            User user = userRepository.findUserByUserId(userProblem.getUserId());
            user.getUserproblems().remove(userProblem);
            userRepository.save(user);
            userProblemRepository.delete(userProblem);
        }
        problemRepository.delete(problem);
    }

}
