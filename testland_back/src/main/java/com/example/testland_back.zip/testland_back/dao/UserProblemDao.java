package com.example.testland_back.dao;

import com.example.testland_back.entity.UserProblem;

public interface UserProblemDao {
    UserProblem findUserProblemByUserIdAndProblemId(Long userId, Long problemId);



    UserProblem saveUserProblem(Long userId, Long problemId, Integer testCount, Integer problemStatus);

    UserProblem updateUserProblemTestCount(Long userId, Long problemId, Integer testCount);
}
