package com.example.testland_back.config;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;



@Component
public class RabbitMQConsumer {
    @RabbitListener(queues = "my_queue")
    public void handleMessage(String message) {
        // 处理接收到的消息
        System.out.println("Received message: " + message);
        //会返回problemId,userId,每个测试点信息（message中），据此需更新数据库与测评状态有关的内容并把结果返回前端

    }
}
