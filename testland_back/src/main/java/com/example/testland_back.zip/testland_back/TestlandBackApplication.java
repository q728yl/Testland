package com.example.testland_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestlandBackApplication {

    public static void main(String[] args) {
        SpringApplication.run(TestlandBackApplication.class, args);
    }

}
