package com.example.testland_back.dao;

import com.example.testland_back.entity.UserProblem;

import java.util.List;

public interface TestDao {
    List<UserProblem> findUserProblemsByUserId(Long userId);
}
