package com.example.testland_back.service;

import com.example.testland_back.entity.UserProblem;
import com.example.testland_back.util.Msg;

public interface UserProblemService {
    UserProblem findUserProblemByUserIdAndProblemId(Long userId, Long problemId);


    Msg saveUserProblem(Long userId, Long problemId, Integer testCount, Integer problemStatus);

    Msg updateUserProblemTestCount(Long userId, Long problemId);
}
